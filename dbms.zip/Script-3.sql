--1 and 2
CREATE TABLE Airline_info (
    airline_id INT PRIMARY KEY,
    airline_code VARCHAR(30) NOT NULL,
    airline_name VARCHAR(50) NOT NULL,
    airline_country VARCHAR(50),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    info varchar(50)
);

CREATE TABLE Airport (
    airport_id INT PRIMARY KEY,
    airport_name VARCHAR(50),
    country VARCHAR(50),
    state VARCHAR(50),
    city VARCHAR(50),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE Baggage_check (
    baggage_check_id INT PRIMARY KEY,
    check_result VARCHAR(50),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    booking_id INT,
    passenger_id INT
);

CREATE TABLE Baggage (
    baggage_id INT PRIMARY KEY,
    weight_in_kg DECIMAL(4,2),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    booking_id INT
);

CREATE TABLE Boarding_pass (
    boarding_pass_id INT PRIMARY KEY,
    booking_id INT,
    seat VARCHAR(50),
    boarding_time TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE Booking_flight (
    booking_flight_id INT PRIMARY KEY,
    booking_id INT,
    flight_id INT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE Booking (
    booking_id INT PRIMARY KEY,
    flight_id INT,
    passenger_id INT,
    booking_platform VARCHAR(50),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    status VARCHAR(50),
    price DECIMAL(7,2)
);

CREATE TABLE Flights (
    flight_id INT PRIMARY KEY,
    sch_departure_time TIMESTAMP,
    sch_arrival_time TIMESTAMP,
    departing_airport_id INT,
    arriving_airport_id INT,
    departing_gate TEXT,
    arriving_gate TEXT,
    airline_id INT,
    act_departure_time TIMESTAMP,
    act_arrival_time TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE Passengers (
    passenger_id INT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(50),
    country_of_citizenship VARCHAR(50),
    country_of_residence VARCHAR(50),
    passport_number VARCHAR(20),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE Security_check (
    security_check_id INT PRIMARY KEY,
    check_result VARCHAR(20),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    passenger_id INT
);
--3
ALTER TABLE Security_check ADD CONSTRAINT fk_security_check_passenger FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id);
ALTER TABLE Booking ADD CONSTRAINT fk_booking_passenger FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id);
ALTER TABLE Baggage_check ADD CONSTRAINT fk_baggage_check_passenger FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id);

ALTER TABLE Baggage_check ADD CONSTRAINT fk_baggage_check_booking FOREIGN KEY (booking_id) REFERENCES Booking(booking_id);
ALTER TABLE Baggage ADD CONSTRAINT fk_baggage_booking FOREIGN KEY (booking_id) REFERENCES Booking(booking_id);
ALTER TABLE Boarding_pass ADD CONSTRAINT fk_boarding_pass_booking FOREIGN KEY (booking_id) REFERENCES Booking(booking_id);
ALTER TABLE Booking_flight ADD CONSTRAINT fk_booking_flight_booking FOREIGN KEY (booking_id) REFERENCES Booking(booking_id);

ALTER TABLE Booking_flight ADD CONSTRAINT fk_booking_flight_flight FOREIGN KEY (flight_id) REFERENCES Flights(flight_id);

ALTER TABLE Flights ADD CONSTRAINT fk_flights_departing_airport FOREIGN KEY (departing_airport_id) REFERENCES Airport(airport_id);

ALTER TABLE Flights ADD CONSTRAINT fk_flights_arriving_airport FOREIGN KEY (arriving_airport_id) REFERENCES Airport(airport_id);

ALTER TABLE Flights ADD CONSTRAINT fk_flights_airline FOREIGN KEY (airline_id) REFERENCES Airline_info(airline_id);

--4

ALTER TABLE Passengers ALTER COLUMN first_name SET NOT NULL;
ALTER TABLE Passengers ALTER COLUMN last_name SET NOT NULL;
ALTER TABLE Passengers ALTER COLUMN date_of_birth SET NOT NULL;
ALTER TABLE Passengers ALTER COLUMN gender SET NOT NULL;

ALTER TABLE Airline_info ALTER COLUMN airline_code SET NOT NULL;
ALTER TABLE Airline_info ALTER COLUMN airline_name SET NOT NULL;
ALTER TABLE Airline_info ALTER COLUMN airline_country SET NOT NULL;

ALTER TABLE Airport ALTER COLUMN airport_name SET NOT NULL;
ALTER TABLE Airport ALTER COLUMN country SET NOT NULL;
ALTER TABLE Airport ALTER COLUMN state SET NOT NULL;
ALTER TABLE Airport ALTER COLUMN city SET NOT NULL;

ALTER TABLE Passengers ADD CONSTRAINT unique_passport_number UNIQUE (passport_number);
ALTER TABLE Airline ADD CONSTRAINT unique_airline_code UNIQUE (airline_code);
ALTER TABLE Passengers ADD CONSTRAINT unique_passport_number UNIQUE (passport_number);

--5
ALTER TABLE airline_info RENAME TO airline;

--6
ALTER TABLE Booking 
RENAME COLUMN price TO ticket_price;

--7
ALTER TABLE Flights
ALTER COLUMN departing_gate TYPE TEXT;

--8
ALTER TABLE airline
DROP COLUMN info;














